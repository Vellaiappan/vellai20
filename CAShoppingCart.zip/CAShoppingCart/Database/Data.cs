﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CAShoppingCart.Database
{
    public class Data
    {
        //Connection to Database server
        public static string connectionString = "Server=LAPTOP-B41E3QR1;" +
                "Database=CAShoppingCart; Integrated Security=true";
    }
}