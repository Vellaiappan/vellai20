﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FSTAADLC2.Database
{
    public class Data
    {
        public static string connectionString = "Server=LAPTOP-B41E3QR1;" +
                   "Database=FSTA; Integrated Security=true";

    }
}