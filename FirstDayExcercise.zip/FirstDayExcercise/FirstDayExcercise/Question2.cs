﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstDayExcercise
{
    class Question2
    {
        static void Main(String[] args)
        {
            Console.Write("Enter your Name:");
            String name = Console.ReadLine();
            Console.WriteLine($"\tGood Morning {name}\nwhere {name} is the name you had input");
        }
    }
}
